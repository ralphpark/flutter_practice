# Chapter 2: Hello Flutter Starter project

There is no starter project for this chapter as you'll create it from scratch using the `flutter` command-line tools. 
